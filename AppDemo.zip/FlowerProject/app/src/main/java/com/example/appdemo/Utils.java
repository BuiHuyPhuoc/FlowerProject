package com.example.appdemo;
import com.example.appdemo.Utils;
import com.example.appdemo.model.GioHang;

import java.util.List;

public class Utils {
    public static List<GioHang> manggiohang;
}
