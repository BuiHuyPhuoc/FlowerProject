package com.example.appdemo.model;

public class ItemMenu {
    public int icon;
    public String tenMenu;

    public ItemMenu(int icon, String tenMenu) {
        this.icon = icon;
        this.tenMenu = tenMenu;
    }
}
