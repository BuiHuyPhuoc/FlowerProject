package com.example.appdemo.adapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.appdemo.R;
import com.example.appdemo.model.Category;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collection;

public class CategoryAdapter extends ArrayAdapter<String> {
    Activity context = null; // Activity chứa Adapter này
    ArrayList<String> categories = null; //List chứa các Category
    int layoutID; //Layout custom do ta tạo, cụ thể là Category View

    public CategoryAdapter(Activity context, ArrayList<String> categories, int layoutID) {
        super(context, layoutID, categories);
        this.context = context;
        this.categories = categories;
        this.layoutID = layoutID;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        // nơi lấy textView trong Category View để hiển thị lên
        LayoutInflater inflater = context.getLayoutInflater();
        convertView = inflater.inflate(layoutID, null);
        if (categories.size() > 0 && position >= 0){
            final TextView txtdisplay = (TextView) convertView.findViewById(R.id.tvCategoryContent);
            final String emp = categories.get(position);
            txtdisplay.setText(emp); //Lấy tên của Category[posiontion], gán vào textview
        }
        return convertView;
    }
}