package com.example.appdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class QLChiTietHoaDonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qlchi_tiet_hoa_don);
    }
}